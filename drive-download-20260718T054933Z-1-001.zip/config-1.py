"""
Configuration, loaded from environment variables (or a .env file locally).
Using pydantic-settings means: define the shape once, get validation and
type coercion for free, and every other module imports `settings` instead
of calling os.environ.get() scattered everywhere.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    db_host: str = "localhost"
    db_port: int = 5432
    db_user: str = "postgres"
    db_password: str = "devpass"
    db_name: str = "playcircle"

    model_config = SettingsConfigDict(env_file=".env", env_prefix="PLAYCIRCLE_")

    @property
    def db_dsn(self) -> str:
        return (
            f"postgresql://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )


settings = Settings()
