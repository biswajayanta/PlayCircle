"""
App entrypoint. `lifespan` is FastAPI's modern way to run startup/shutdown
code — connect the DB pool when the app boots, close it cleanly on exit,
rather than connecting on every request.

Run locally with:
    uvicorn app.main:app --reload
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI

from app.db import connect_db, disconnect_db
from app.routers import health, sports


@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_db()
    yield
    await disconnect_db()


app = FastAPI(
    title="PlayCircle API",
    description="Backend for PlayCircle — social sports meetup, stats, and wellness app.",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(health.router)
app.include_router(sports.router)
